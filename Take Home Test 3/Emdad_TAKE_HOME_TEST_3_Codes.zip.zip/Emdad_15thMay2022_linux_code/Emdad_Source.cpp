#include <iostream>
#include <time.h>
#include <stdint.h>
#include <stdlib.h>

#define NANO 1000000000L

using namespace std;

const int array_size = 4096; //array size {we will keep change it to 8,16,32,64,128,256,512,1024,2048,4096}
static float X[array_size];
static float Y[array_size];

float Emdad_DotProductPointer(float* arr1, float* arr2, const int size);
int main() {
	uint64_t elapsedTime;
	uint64_t total_time = 0;
	int d_prod;
	struct timespec startTime, endTime;

	for (int i = 0; i < array_size; i++) {
		X[i] = i / 2.0;
		Y[i] = i / 3.0;
	}

	cout << "Array size: " << array_size << endl;
	
	for (int n = 0; n < 10; n++) {
		clock_gettime(CLOCK_PROCESS_CPUTIME_ID, &startTime);
		d_prod = Emdad_DotProductPointer(&X[0], &Y[0], array_size);
		clock_gettime(CLOCK_PROCESS_CPUTIME_ID, &endTime);
		
		elapsedTime = NANO * (endTime.tv_sec - startTime.tv_sec) + (endTime.tv_nsec - startTime.tv_nsec);
	
		total_time += elapsedTime;
		}

	cout << "Average time: " << (total_time / 10) << " ns" << endl;

	return 0;
}

