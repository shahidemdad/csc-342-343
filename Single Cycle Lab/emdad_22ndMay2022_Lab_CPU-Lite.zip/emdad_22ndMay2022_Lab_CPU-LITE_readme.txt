MdShahid Emdad
CSc 34200/34300
Professor Izidor Gertner
May 22nd, 2022
							README File
					(ignore all the qoutation marks for code)

1. Locate a zip file, "emdad_22ndMay2022_lab_code_files". Unzip it.

2. The "emdad_22ndMay2022_lab_code_files" folder has 2 files:
	i. emdad_22ndMay2022_lab_cpu-lite.qar
	ii. emdad_CPU_test_program.asm
3. Open "emdad_22ndMay2022_lab_cpu-lite.qar" using quartus and unarchieve the project. It has all the vhdl files, compile each on Quartus.

4. Open MARS simulator and run "emdad_CPU_test_program.asm". Retrieve all the instructions and load it into the instruction memory.

5. Create a new project in Modelsim with name “emdad_single_cpu_lab_22May2022”.

5. Click "add existing file" to add the vhdl files in the Modelsim project and compile all.

6. Start simulation Then, run the simulations, add waves one by one for all enter your preferred value to check if its correct.