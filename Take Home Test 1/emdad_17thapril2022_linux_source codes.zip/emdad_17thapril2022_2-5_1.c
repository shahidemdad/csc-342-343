#include <stdio.h>

int main() {
	static int a = 0;
	static int b = 0;
	static int c = 0;
	a = b + c;
}
