#include <stdio.h>

int myAdd(int a, int b) {
	return (a + b);
}

int main() {
	int a = 4;
	int b = 5;
	myAdd(a, b);
	return 0;
}
