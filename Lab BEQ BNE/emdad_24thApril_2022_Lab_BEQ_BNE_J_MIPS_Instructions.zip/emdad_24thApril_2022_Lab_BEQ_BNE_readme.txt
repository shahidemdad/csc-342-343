							README File

1. locate the zip a .QAR extension file "emdad_24thApril_2022_Lab_BEQ_BNE.QAR" which contains all the archieved VHDL codes, mif files for lab project.
2. Open it with quartus and then unarchieve the project. It will show the necessary files for the project such as VHDL and mif etc.
3. Start processing to compile and compile all of them.
4. After then, open modelsim and create project and add the necessary VHDL files for the specific projects and compile them.
5. Start simulation for waveforms and choose the testbench and run 600ps to see the waveform.