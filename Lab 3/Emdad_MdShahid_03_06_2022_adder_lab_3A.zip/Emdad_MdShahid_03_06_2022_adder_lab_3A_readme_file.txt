Farnaz Zinnah
03/06/2022
CSC 34200/34300
Professor Izidor Gertner
												README file for Adder lab

As the source codes stored as a zip file. it need to extract first then, get into the "lab 3" then follow accordingly as below:

i. To start with, I open the QAR file in Quartus II.
ii. After opening it, I can set the file named, “Emdad_03_02_2022_half_adder as top-level entity and compile the entire project.
iii. I have the following files in the project:
	a. Emdad 03 02 22 NBitLPMAddSub
	b. Emdad 03 02 2022 32 bit
	c. Emdad MdShahid 03 02 2022_16 bit
	d. Emdad_ MdShahid_03_02_2022 _four bit add_sub
	e. Emdad_MdShahid_03_02_2022_four_bit full adder
	f. Emdad MdShahid 03 02 2022 half adder
	g. Emdad_MdShahid_03_02_2022_n_bit_add_sub_behavioral
	h. Emdad_MdShahid_03_02_2022_n_bit_add_sub_flags
	i. Emdad_MdShahid_03_02_2022_one_bit_full_adder
	j. Emdad MdShahid_03_02_2022 _package
	k. Emdad_MdShahid_03_02_2022_task8
	l. Emdad_MdShahid_16_bit_simulation
	m. Emdad _MdShahid_four bit simulation
	n. Emdad MdShahid_NBitLPMAddSub
iv. After compiling each file, use modelsim for modelsim for simulation
vi. I clicked each file in ModelSim and go to the project download directory and from there I add the necessary project files for simulation
viii. Then, I ran simulations by adding waves.
x. Finally, I entered preferred value to check if its correct or use testbench for the waveforms output.