							README File

1. locate the file .QAR extension file "Emdad_10thApril_ALU" which contains all the archieved VHDL codes, mif files, instructions and simulated waveforms for the lab project.
2. Open it with quartus and then unarchieve the project. It will show the necessary files for the project.
3. Start processing to compile.
4. After then, open modelsim and create project and add the "Emdad_10thApril_ALU" and compile it.
5. Start simulation for waveforms and add the wave to the wave window and force inputs to get the right waveform.