							README File

1. locate the zip folder "Emdad_Midterm_Lab_March_23_2022_code" which contains all the archieved VHDL codes, mif files, instructions and simulated waveforms for lab project.

2. After unzip it, there will another zip folder name "Emdad_Midterm_Lab_March_23_2022_code" where all the source codes exits alongside the mif files and need to unzip it too.

3. After unzip, there will be 6 folders. Every assignment part is distingushed in its own folder. These are folder exists(in order):
	Assignment 1:
		Emdad_23rdMarch_lpm_ram_32x16
		Emdad_23rdMarch2022_lpm_ram_32x32
		Emdad_23rdMarch2022_lpm_dual_port_ram_32x32
	Assignment 2:
		Emdad_23rdMarch2022_32_bit_add_sub_scratch
		Emdad_23rdMarch_lpm_add_sub_32_bit
		Emdad_23rdMarch_circuits_flags

Each folder contains a .QAR extension file.

4. Open it with quartus and then unarchieve the project. It will show the necessary files for the project such as VHDL and mif etc.
5. Start processing to compile.
6. After then, open modelsim and create project and add the necessary VHDL files for the specific projects and compile them.
7. Start simulation for waveforms and add the wave to the wave window and force inputs as instructed to get the right waveform.